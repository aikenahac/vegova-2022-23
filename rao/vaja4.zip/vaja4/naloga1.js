for (let i = 1; i < 11; i++) {
  console.log(i);
}