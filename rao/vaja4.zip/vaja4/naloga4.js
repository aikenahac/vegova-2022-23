const string = "Ne ne, vse obtožbe glede tega zanikam. Sem popolnoma nedolžen, majkemi.";

console.log(string.indexOf('pop'));